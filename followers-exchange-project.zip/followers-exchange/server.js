require("dotenv").config();

const express = require("express");
const helmet = require("helmet");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const path = require("path");

const app = express();
const isProduction = process.env.NODE_ENV === "production";
const port = Number(process.env.PORT || 3000);

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required. Copy .env.example to .env and configure PostgreSQL.");
}
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be set to a random string of at least 32 characters.");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isProduction ? { rejectUnauthorized: false } : undefined,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

if (isProduction) app.set("trust proxy", 1);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  store: new PgSession({
    pool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  name: "followers.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 24 * 14
  }
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 12,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "محاولات كثيرة. حاول بعد 15 دقيقة." }
});

const schema = `
CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(70) NOT NULL,
  username VARCHAR(24) NOT NULL UNIQUE,
  email VARCHAR(254) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  points INTEGER NOT NULL DEFAULT 0 CHECK (points >= 0),
  role VARCHAR(10) NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS social_accounts (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform VARCHAR(20) NOT NULL CHECK (platform IN ('instagram','tiktok','x','youtube')),
  social_username VARCHAR(40) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(platform, social_username)
);

CREATE TABLE IF NOT EXISTS promotions (
  id BIGSERIAL PRIMARY KEY,
  account_id BIGINT NOT NULL REFERENCES social_accounts(id) ON DELETE CASCADE,
  owner_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  cost INTEGER NOT NULL DEFAULT 30 CHECK (cost > 0),
  status VARCHAR(15) NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','closed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS task_claims (
  id BIGSERIAL PRIMARY KEY,
  promotion_id BIGINT NOT NULL REFERENCES promotions(id) ON DELETE CASCADE,
  worker_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(15) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  UNIQUE(promotion_id, worker_id)
);

CREATE TABLE IF NOT EXISTS point_ledger (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL,
  reason VARCHAR(180) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_promotions_status ON promotions(status);
CREATE INDEX IF NOT EXISTS idx_claims_status ON task_claims(status);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON point_ledger(user_id, created_at DESC);
`;

async function initializeDatabase() {
  await pool.query(schema);
  const adminEmail = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  if (adminEmail) {
    await pool.query("UPDATE users SET role='admin' WHERE email=$1", [adminEmail]);
  }
}

function cleanText(value) {
  return String(value || "").trim();
}

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 254;
}

function validUsername(value) {
  return /^[a-zA-Z0-9_.-]{3,24}$/.test(value);
}

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

async function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "سجّل الدخول أولاً." });
  try {
    const result = await pool.query(
      "SELECT id, name, username, email, points, role, created_at FROM users WHERE id=$1",
      [req.session.userId]
    );
    if (!result.rowCount) {
      req.session.destroy(() => {});
      return res.status(401).json({ error: "انتهت الجلسة. سجّل الدخول مجدداً." });
    }
    req.user = result.rows[0];
    next();
  } catch (error) {
    next(error);
  }
}

function requireAdmin(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "هذه الصفحة للمسؤول فقط." });
  next();
}

app.get("/api/health", asyncRoute(async (req, res) => {
  await pool.query("SELECT 1");
  res.json({ ok: true, database: "connected" });
}));

app.post("/api/register", authLimiter, asyncRoute(async (req, res) => {
  const name = cleanText(req.body.name);
  const username = cleanText(req.body.username).toLowerCase();
  const email = cleanText(req.body.email).toLowerCase();
  const password = String(req.body.password || "");

  if (name.length < 2 || name.length > 70) return res.status(400).json({ error: "الاسم يجب أن يكون بين حرفين و70 حرفاً." });
  if (!validUsername(username)) return res.status(400).json({ error: "اسم المستخدم: 3 إلى 24 حرفاً إنجليزياً أو أرقام أو _ أو ." });
  if (!validEmail(email)) return res.status(400).json({ error: "البريد الإلكتروني غير صحيح." });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل." });

  const passwordHash = await bcrypt.hash(password, 12);
  try {
    const result = await pool.query(
      `INSERT INTO users(name,username,email,password_hash,points)
       VALUES($1,$2,$3,$4,100)
       RETURNING id,name,username,email,points,role,created_at`,
      [name, username, email, passwordHash]
    );
    const user = result.rows[0];
    await pool.query(
      "INSERT INTO point_ledger(user_id,amount,reason) VALUES($1,100,'رصيد ترحيبي')",
      [user.id]
    );
    req.session.userId = user.id;
    res.status(201).json({ user });
  } catch (error) {
    if (error.code === "23505") return res.status(409).json({ error: "البريد أو اسم المستخدم مستخدم بالفعل." });
    throw error;
  }
}));

app.post("/api/login", authLimiter, asyncRoute(async (req, res) => {
  const identity = cleanText(req.body.identity).toLowerCase();
  const password = String(req.body.password || "");
  const result = await pool.query(
    "SELECT id,name,username,email,password_hash,points,role,created_at FROM users WHERE email=$1 OR username=$1",
    [identity]
  );
  if (!result.rowCount || !(await bcrypt.compare(password, result.rows[0].password_hash))) {
    return res.status(401).json({ error: "بيانات الدخول غير صحيحة." });
  }
  const user = result.rows[0];
  req.session.regenerate(error => {
    if (error) return res.status(500).json({ error: "تعذر إنشاء الجلسة." });
    req.session.userId = user.id;
    res.json({
      user: {
        id: user.id, name: user.name, username: user.username,
        email: user.email, points: user.points, role: user.role,
        created_at: user.created_at
      }
    });
  });
}));

app.post("/api/logout", (req, res) => {
  req.session.destroy(error => {
    if (error) return res.status(500).json({ error: "تعذر تسجيل الخروج." });
    res.clearCookie("followers.sid");
    res.json({ ok: true });
  });
});

app.get("/api/me", requireAuth, (req, res) => res.json({ user: req.user }));

app.get("/api/accounts", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(
    "SELECT id,platform,social_username,created_at FROM social_accounts WHERE user_id=$1 ORDER BY id DESC",
    [req.user.id]
  );
  res.json({ accounts: result.rows });
}));

app.post("/api/accounts", requireAuth, asyncRoute(async (req, res) => {
  const platform = cleanText(req.body.platform);
  const socialUsername = cleanText(req.body.social_username).replace(/^@/, "");
  if (!["instagram","tiktok","x","youtube"].includes(platform)) return res.status(400).json({ error: "المنصة غير مدعومة." });
  if (!/^[a-zA-Z0-9._-]{2,40}$/.test(socialUsername)) return res.status(400).json({ error: "اسم الحساب غير صحيح." });

  try {
    const result = await pool.query(
      "INSERT INTO social_accounts(user_id,platform,social_username) VALUES($1,$2,$3) RETURNING id,platform,social_username,created_at",
      [req.user.id, platform, socialUsername]
    );
    res.status(201).json({ account: result.rows[0] });
  } catch (error) {
    if (error.code === "23505") return res.status(409).json({ error: "هذا الحساب مضاف بالفعل." });
    throw error;
  }
}));

app.delete("/api/accounts/:id", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(
    "DELETE FROM social_accounts WHERE id=$1 AND user_id=$2 RETURNING id",
    [req.params.id, req.user.id]
  );
  if (!result.rowCount) return res.status(404).json({ error: "الحساب غير موجود." });
  res.json({ ok: true });
}));

app.post("/api/promotions", requireAuth, asyncRoute(async (req, res) => {
  const accountId = Number(req.body.account_id);
  const cost = 30;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const account = await client.query(
      "SELECT id FROM social_accounts WHERE id=$1 AND user_id=$2",
      [accountId, req.user.id]
    );
    if (!account.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "الحساب غير موجود ضمن حساباتك." });
    }
    const user = await client.query("SELECT points FROM users WHERE id=$1 FOR UPDATE", [req.user.id]);
    if (user.rows[0].points < cost) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "رصيدك لا يكفي. تحتاج 30 نقطة." });
    }
    await client.query("UPDATE users SET points=points-$1 WHERE id=$2", [cost, req.user.id]);
    const promo = await client.query(
      "INSERT INTO promotions(account_id,owner_id,cost) VALUES($1,$2,$3) RETURNING id",
      [accountId, req.user.id, cost]
    );
    await client.query(
      "INSERT INTO point_ledger(user_id,amount,reason) VALUES($1,$2,$3)",
      [req.user.id, -cost, "إنشاء حملة ترويج"]
    );
    await client.query("COMMIT");
    res.status(201).json({ promotion_id: promo.rows[0].id, points: user.rows[0].points - cost });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/api/tasks", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT p.id AS promotion_id, p.owner_id, a.platform, a.social_username,
       EXISTS(SELECT 1 FROM task_claims c WHERE c.promotion_id=p.id AND c.worker_id=$1) AS claimed
     FROM promotions p
     JOIN social_accounts a ON a.id=p.account_id
     WHERE p.status='active' AND p.owner_id<>$1
       AND NOT EXISTS (
         SELECT 1 FROM task_claims c
         WHERE c.promotion_id=p.id AND c.worker_id=$1 AND c.status IN ('pending','approved')
       )
     ORDER BY p.created_at ASC LIMIT 100`,
    [req.user.id]
  );
  res.json({ tasks: result.rows });
}));

app.post("/api/tasks/:id/claim", requireAuth, asyncRoute(async (req, res) => {
  const promotionId = Number(req.params.id);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const promo = await client.query(
      "SELECT id,owner_id FROM promotions WHERE id=$1 AND status='active' FOR UPDATE",
      [promotionId]
    );
    if (!promo.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "المهمة غير متاحة." });
    }
    if (String(promo.rows[0].owner_id) === String(req.user.id)) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "لا يمكنك تنفيذ مهمة حسابك." });
    }
    const inserted = await client.query(
      "INSERT INTO task_claims(promotion_id,worker_id) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING id",
      [promotionId, req.user.id]
    );
    if (!inserted.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "سبق أن أرسلت طلب هذه المهمة." });
    }
    await client.query("COMMIT");
    res.status(201).json({ message: "تم إرسال طلبك للمراجعة. تُضاف النقاط بعد موافقة المسؤول." });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/api/history", requireAuth, asyncRoute(async (req, res) => {
  const result = await pool.query(
    "SELECT amount,reason,created_at FROM point_ledger WHERE user_id=$1 ORDER BY id DESC LIMIT 50",
    [req.user.id]
  );
  res.json({ history: result.rows });
}));

app.get("/api/admin/claims", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT c.id,c.status,c.created_at,
      w.name AS worker_name,w.username AS worker_username,
      p.owner_id,a.platform,a.social_username
     FROM task_claims c
     JOIN users w ON w.id=c.worker_id
     JOIN promotions p ON p.id=c.promotion_id
     JOIN social_accounts a ON a.id=p.account_id
     WHERE c.status='pending' ORDER BY c.created_at ASC`
  );
  res.json({ claims: result.rows });
}));

app.post("/api/admin/claims/:id/review", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const claimId = Number(req.params.id);
  const decision = cleanText(req.body.decision);
  if (!["approve","reject"].includes(decision)) return res.status(400).json({ error: "قرار غير صحيح." });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const claim = await client.query(
      `SELECT c.id,c.worker_id,c.status,p.owner_id
       FROM task_claims c JOIN promotions p ON p.id=c.promotion_id
       WHERE c.id=$1 FOR UPDATE OF c`,
      [claimId]
    );
    if (!claim.rowCount || claim.rows[0].status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "الطلب غير موجود أو تمت مراجعته." });
    }

    const row = claim.rows[0];
    if (decision === "approve") {
      await client.query("UPDATE task_claims SET status='approved',reviewed_at=NOW() WHERE id=$1", [claimId]);
      await client.query("UPDATE users SET points=points+10 WHERE id=$1", [row.worker_id]);
      await client.query(
        "INSERT INTO point_ledger(user_id,amount,reason) VALUES($1,10,$2)",
        [row.worker_id, "مكافأة مهمة متابعة تمت مراجعتها"]
      );
    } else {
      await client.query("UPDATE task_claims SET status='rejected',reviewed_at=NOW() WHERE id=$1", [claimId]);
    }
    await client.query("COMMIT");
    res.json({ ok: true });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/api/admin/summary", requireAuth, requireAdmin, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT
      (SELECT COUNT(*) FROM users) AS users,
      (SELECT COUNT(*) FROM social_accounts) AS accounts,
      (SELECT COUNT(*) FROM promotions WHERE status='active') AS promotions,
      (SELECT COUNT(*) FROM task_claims WHERE status='pending') AS pending_claims`
  );
  res.json({ summary: result.rows[0] });
}));

app.use(express.static(path.join(__dirname, "public")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: "حدث خطأ في الخادم. حاول لاحقاً." });
});

initializeDatabase().then(() => {
  app.listen(port, () => console.log(`Followers Exchange listening on ${port}`));
}).catch(error => {
  console.error("Database initialization failed:", error);
  process.exit(1);
});
